import 'package:flutter/material.dart';
import 'package:frontend/ui/app.dart';
void main(){
  runApp(const MyApp());
}